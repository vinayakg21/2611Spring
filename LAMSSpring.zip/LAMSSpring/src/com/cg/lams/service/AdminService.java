package com.cg.lams.service;

import com.cg.lams.entity.LoanProgramsOffered;

public interface AdminService {

	void addLoanProgram(LoanProgramsOffered loanProgram);

}
