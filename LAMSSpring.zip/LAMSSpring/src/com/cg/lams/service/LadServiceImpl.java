package com.cg.lams.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lams.dao.LadDao;

@Service
@Transactional
public class LadServiceImpl implements LadService {

	@Autowired
	LadDao ldao;
}
