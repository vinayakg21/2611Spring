package com.cg.lams.service;

import java.util.List;

import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;

public interface CommonService {

	public EndUsers login(EndUsers user)throws LAMSException;

	public List<LoanProgramsOffered> viewLoanProgramOffered() throws LAMSException;
}
