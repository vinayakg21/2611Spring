package com.cg.lams.service;

public interface LadService {

}
