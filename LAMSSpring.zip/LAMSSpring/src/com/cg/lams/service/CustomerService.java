package com.cg.lams.service;

import com.cg.lams.entity.CustomerDetails;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

public interface CustomerService {

	LoanProgramsOffered getLoanProgram(String programName);

	void addLoanDetails(LoanApplication loanApplication);

	void addCustDetails(CustomerDetails customerDetails);

}
