package com.cg.lams.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lams.dao.CustomerDao;
import com.cg.lams.entity.CustomerDetails;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao custdao;

	@Override
	public LoanProgramsOffered getLoanProgram(String programName) {
		// TODO Auto-generated method stub
		return custdao.getLoanProgram(programName);
	}

	@Override
	public void addLoanDetails(LoanApplication loanApplication) {
		// TODO Auto-generated method stub
		custdao.addLoanDetails(loanApplication);
	}

	@Override
	public void addCustDetails(CustomerDetails customerDetails) {
		// TODO Auto-generated method stub
		custdao.addCustDetails(customerDetails);
	}
}
