package com.cg.lams.dao;

import com.cg.lams.entity.CustomerDetails;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

public interface CustomerDao {

	LoanProgramsOffered getLoanProgram(String programName);

	void addLoanDetails(LoanApplication loanApplication);

	void addCustDetails(CustomerDetails customerDetails);

}
