package com.cg.lams.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class LadDaoImpl implements LadDao {

	@PersistenceContext
	EntityManager em;
}
