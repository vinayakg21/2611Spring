package com.cg.lams.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.lams.entity.LoanProgramsOffered;

@Repository
public class AdminDaoImpl implements AdminDao {

	@PersistenceContext
	EntityManager em;
	
	public AdminDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addLoanProgram(LoanProgramsOffered loanProgram) {
		// TODO Auto-generated method stub
		em.persist(loanProgram);
	}

}
