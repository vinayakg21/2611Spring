package com.cg.lams.dao;

public interface LadDao {

}
