package com.cg.lams.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.lams.entity.CustomerDetails;
import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;
import com.cg.lams.service.AdminService;
import com.cg.lams.service.CommonService;
import com.cg.lams.service.CustomerService;
import com.cg.lams.service.LadService;

@Controller
public class LAMSController {
	
	@Autowired
	CommonService cser;
	
	@Autowired
	AdminService aser;
	
	@Autowired
	CustomerService custser;
	
	@Autowired
	LadService lser;
	

	public LAMSController() {
		// TODO Auto-generated constructor stub
	}
	
	@RequestMapping("adminPage")
	public String goAdminLogin(Model model){
		
		model.addAttribute("user", new EndUsers());
		return "AdminLogin";
		
	}
	
	@RequestMapping("ladPage")
	public String goLADLogin(Model model){
		
		model.addAttribute("user", new EndUsers());
		return "LADLogin";
		
	}
	
	@RequestMapping("customerPage")
	public String goCustomerHome(Model model){
		
		return "CustomerHome";
		
	}
	
	@RequestMapping("adminLoginAction")
	public String adminLogin(@ModelAttribute("user") @Valid EndUsers user, BindingResult res,Model model) throws LAMSException{
		user.setRole("Admin");
		if(res.hasErrors()){
			model.addAttribute("user",user);
			return "AdminLogin";
		}
		else
		{
			EndUsers userResult = null;			
			try {
				userResult = cser.login(user);
			} catch (LAMSException e) {
				// TODO Auto-generated catch block
				throw new LAMSException("Invalid User");
			}
			return "AdminHome";
		}
	}
	
	@RequestMapping("ladLoginAction")
	public String ladlogin(@ModelAttribute("user") @Valid EndUsers user, BindingResult res,Model model) throws LAMSException{
		user.setRole("LAD");
		if(res.hasErrors()){
			model.addAttribute("user",user);
			return "LADLogin";
		}
		else
		{
			EndUsers userResult = null;			
			try {
				userResult = cser.login(user);
			} catch (LAMSException e) {
				// TODO Auto-generated catch block
				throw new LAMSException("Invalid User");
			}
			return "LADHome";
		}
	}	
	
	@ExceptionHandler(value=LAMSException.class)
	public String handleException(Model model,Exception e) {
		
		System.out.println(e.getMessage());
		model.addAttribute("message", e.getMessage());
		return "Exception";
	}

	@ExceptionHandler(value=NullPointerException.class)
	public String handleNullPointerException(Model model,Exception e) {
		
		System.out.println(e.getMessage());
		model.addAttribute("message", e.getMessage());
		return "Exception";
	}
	
	@RequestMapping("addLoanPage")
	public String goAddLoan(Model model){
		
		model.addAttribute("loanProgram", new LoanProgramsOffered());
		return "AddLoanProgram";
		
	}
	
	@RequestMapping("addLoanProgramAction")
	public String register(@ModelAttribute("loanProgram") @Valid LoanProgramsOffered loanProgram, BindingResult res,Model model){
		
		if(res.hasErrors()){
			model.addAttribute("loanProgram",loanProgram);
			return "AddLoanProgram";
		}
		else
		{
			aser.addLoanProgram(loanProgram);
			System.out.println("Swastika");
			System.out.println(loanProgram);
			//model.addAttribute("msg","Loan Program Added Successfully with name"+loanProgram.getProgramName());
			return "ADDLoanProgramSuccess";
		}
	}
	
	@RequestMapping("viewAllLoanPage")
	public String goViewAllLoan(Model model){
		
		try {
			List<LoanProgramsOffered> loanlist = cser.viewLoanProgramOffered();
			model.addAttribute("loanlist",loanlist);
			
			
		} catch (LAMSException e) {
			// TODO Auto-generated catch block
			System.out.println("List is not present");
		}
		return "ViewLoanProgram";
		
	}
	
	@RequestMapping("viewLoanPageCust")
	public String goViewLoanPageCust(Model model){
		
		try {
			List<LoanProgramsOffered> loanlist = cser.viewLoanProgramOffered();
			model.addAttribute("loanlist",loanlist);
			
			
		} catch (LAMSException e) {
			// TODO Auto-generated catch block
			System.out.println("List is not present");
		}
		return "ViewLoanProgramCust";
		
	}
	
	@RequestMapping("applyForLoan")
	public String addLoanApp(Model model, @RequestParam("id") String programName){
		
		model.addAttribute("programName",programName);
		model.addAttribute("loanApplication",new LoanApplication());
		
		LoanProgramsOffered loanProgram = custser.getLoanProgram(programName);
		System.out.println(loanProgram);
		
		model.addAttribute("programName", programName);
		return "ApplyLoanApplication";
	}
	
	
	@RequestMapping("addCustDetails")
	public String ladlogin(@ModelAttribute("loanApplication") @Valid LoanApplication loanApplication, BindingResult res,Model model) throws LAMSException{
		
		if(res.hasErrors()){
			model.addAttribute("loanApplication",loanApplication);
			return "ApplyLoanApplication";
		}
		else
		{
			
			LocalDate idate = LocalDate.now().plus(10, ChronoUnit.DAYS);
			loanApplication.setApplicationDate(Date.valueOf(LocalDate.now()));
			loanApplication.setStatus("Applied");		
			loanApplication.setDateOfInterview(Date.valueOf(idate));
			System.out.println(loanApplication);
			custser.addLoanDetails(loanApplication);
			model.addAttribute("customerDetails", new CustomerDetails());
			return "AddCustomerDetails";
		}
	}
	
	@RequestMapping("addCustAction")
	public String ladlogin(@ModelAttribute("customerDetails") @Valid CustomerDetails customerDetails, BindingResult res,Model model) throws LAMSException{
		
		if(res.hasErrors()){
			model.addAttribute("customerDetails",customerDetails);
			return "AddCustomerDetails";
		}
		else
		{
			custser.addCustDetails(customerDetails);
			return "ApplySuccess";
		}
	}
}
